#pragma once
// frame_source.h — Shared-memory ring buffer consumer (camera server side).
//
// The companion app (Process A) decodes video/image frames via FFmpeg and
// writes raw NV12 pixels into an Ashmem ring buffer. This module receives
// the Ashmem file descriptor over a Unix Domain Socket and maps it.
//
// The camera server hook (Process B) calls frame_source_get_frame() on every
// processCaptureResult invocation to obtain a pointer to the most recently
// completed frame. The call is non-blocking: if no new frame is ready, it
// returns the previous pointer (frame repeat strategy for FPS mismatch).
//
// Ring buffer layout (3 slots, each = master_width * master_height * 3/2 bytes):
//
//   ┌──────────────┬──────────────┬──────────────┬────────────┐
//   │  Header (64B)│   Slot 0     │   Slot 1     │   Slot 2   │
//   └──────────────┴──────────────┴──────────────┴────────────┘
//
// Header (64 bytes, cache-line aligned):
//   uint32_t magic         — 0xAMKU5H01
//   uint32_t write_slot    — index of the slot FFmpeg last wrote into
//   uint32_t master_width  — source frame width
//   uint32_t master_height — source frame height
//   uint32_t slot_stride   — bytes per row in a slot (may be > width)
//   uint8_t  padding[44]

#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

#define FRAME_SOURCE_MAGIC  0xAMKU5H01U
#define FRAME_RING_SLOTS    3

typedef struct FrameSourceHeader {
    uint32_t magic;
    volatile uint32_t write_slot;    // written by producer (app), read by consumer
    uint32_t master_width;
    uint32_t master_height;
    uint32_t slot_stride;            // bytes per row (YUV Y plane)
    uint8_t  _pad[44];
} __attribute__((packed)) FrameSourceHeader;

typedef struct FrameData {
    uint8_t  *y_plane;
    uint8_t  *uv_plane;
    uint32_t  width;
    uint32_t  height;
    uint32_t  stride;
} FrameData;

// Initialize from an Ashmem fd. Takes ownership of fd (calls dup internally).
// Returns 0 on success.
int  frame_source_init(int ashmem_fd);

// Release the mapping.
void frame_source_destroy(void);

// Returns true if a valid frame mapping is available.
bool frame_source_ready(void);

// Get the most recently written frame (non-blocking, returns previous on
// no new frame). Returns false if no mapping is available.
bool frame_source_get(FrameData *out);

#ifdef __cplusplus
}
#endif
