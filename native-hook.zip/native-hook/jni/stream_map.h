#pragma once
// stream_map.h — Stream identity map built during configure_streams().
//
// Problem: multiple streams can share the same pixel format and resolution
// (e.g. two BLOB streams — one for AI face mesh, one for full-res snapshot).
// Relying on format/size alone to route injection logic is unreliable and
// can cause the wrong processing path to run on the wrong surface.
//
// Solution: Build a pointer→purpose map during configure_streams() using the
// stream's memory address as a unique, session-scoped identity key. The map
// is cleared and rebuilt every time configure_streams() is called.
//
// Additionally, strip GRALLOC_USAGE_PROTECTED here (before buffer allocation)
// so the system allocates CPU-accessible pages instead of TrustZone pages.

#include "include/camera3_compat.h"
#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    STREAM_ROLE_UNKNOWN      = 0,
    STREAM_ROLE_PREVIEW      = 1,   // HAL_PIXEL_FORMAT_IMPLEMENTATION_DEFINED, stream[0]
    STREAM_ROLE_VIDEO        = 2,   // HAL_PIXEL_FORMAT_IMPLEMENTATION_DEFINED, stream[1+]
    STREAM_ROLE_SNAPSHOT     = 3,   // HAL_PIXEL_FORMAT_BLOB, width > 2000
    STREAM_ROLE_ML_THUMB     = 4,   // HAL_PIXEL_FORMAT_BLOB, width <= 2000
    STREAM_ROLE_YUV_ANALYSIS = 5,   // HAL_PIXEL_FORMAT_YCBCR_420_888 small
    STREAM_ROLE_RAW          = 6,   // HAL_PIXEL_FORMAT_RAW16 — skip
    STREAM_ROLE_HDR          = 7,   // HAL_PIXEL_FORMAT_YCBCR_P010
} StreamRole;

// Call this from the hooked configure_streams() before forwarding the call.
// Strips GRALLOC_USAGE_PROTECTED and builds the identity map.
void stream_map_rebuild(camera3_stream_configuration_t *cfg);

// Clear the map (call when the camera session tears down).
void stream_map_clear(void);

// Look up the role for a stream pointer (returns STREAM_ROLE_UNKNOWN if
// the stream was not seen during the last configure_streams()).
StreamRole stream_map_get_role(const camera3_stream_t *stream);

// Returns true if synthetic frame injection should be attempted for a buffer
// with the given role and buffer status. Automatically skips ERROR and RAW.
bool stream_map_should_inject(StreamRole role, int buffer_status);

#ifdef __cplusplus
}
#endif
