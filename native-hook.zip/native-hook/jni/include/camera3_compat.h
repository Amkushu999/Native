// camera3_compat.h — Standalone-safe subset of AOSP camera3.h + gralloc.h
// These definitions are taken verbatim from:
//   hardware/libhardware/include/hardware/camera3.h
//   hardware/libhardware/include/hardware/gralloc.h
//   system/core/include/system/graphics.h
// They must NOT be compiled when building inside the full AOSP tree.
#pragma once

#include <stdint.h>
#include <system/graphics.h>  // For android_ycbcr, HAL_PIXEL_FORMAT_*

// ---------------------------------------------------------------------------
// GRALLOC usage flags (gralloc.h)
// ---------------------------------------------------------------------------
#ifndef GRALLOC_USAGE_SW_READ_OFTEN
#define GRALLOC_USAGE_SW_READ_OFTEN    0x00000003U
#endif
#ifndef GRALLOC_USAGE_SW_WRITE_OFTEN
#define GRALLOC_USAGE_SW_WRITE_OFTEN   0x00000030U
#endif
#ifndef GRALLOC_USAGE_SW_WRITE_RARELY
#define GRALLOC_USAGE_SW_WRITE_RARELY  0x00000020U
#endif
#ifndef GRALLOC_USAGE_PROTECTED
#define GRALLOC_USAGE_PROTECTED        0x00004000U
#endif

// ---------------------------------------------------------------------------
// HAL pixel format constants (system/graphics.h may already define these)
// ---------------------------------------------------------------------------
#ifndef HAL_PIXEL_FORMAT_RGBA_8888
#define HAL_PIXEL_FORMAT_RGBA_8888    1
#endif
#ifndef HAL_PIXEL_FORMAT_BLOB
#define HAL_PIXEL_FORMAT_BLOB         0x21   // 33  — JPEG snapshots
#endif
#ifndef HAL_PIXEL_FORMAT_RAW16
#define HAL_PIXEL_FORMAT_RAW16        0x20   // 32  — RAW sensor, skip
#endif
#ifndef HAL_PIXEL_FORMAT_IMPLEMENTATION_DEFINED
#define HAL_PIXEL_FORMAT_IMPLEMENTATION_DEFINED 0x22 // 34 — preview/video
#endif
#ifndef HAL_PIXEL_FORMAT_YCBCR_420_888
#define HAL_PIXEL_FORMAT_YCBCR_420_888 0x23  // 35  — flexible YUV
#endif
#ifndef HAL_PIXEL_FORMAT_YCrCb_420_SP
#define HAL_PIXEL_FORMAT_YCrCb_420_SP  0x11  // 17  — NV21 legacy
#endif
#ifndef HAL_PIXEL_FORMAT_YCBCR_P010
#define HAL_PIXEL_FORMAT_YCBCR_P010    0x36  // 54  — HDR10 (10-bit NV12)
#endif

// ---------------------------------------------------------------------------
// camera3_stream_type_t
// ---------------------------------------------------------------------------
typedef enum camera3_stream_type {
    CAMERA3_STREAM_OUTPUT = 0,
    CAMERA3_STREAM_INPUT  = 1,
    CAMERA3_STREAM_BIDIRECTIONAL = 2,
} camera3_stream_type_t;

// ---------------------------------------------------------------------------
// camera3_stream_t  (hardware/libhardware/include/hardware/camera3.h §1551)
// ---------------------------------------------------------------------------
typedef struct camera3_stream {
    // Set by framework before configure_streams()
    int                     stream_type;   // camera3_stream_type_t
    uint32_t                width;
    uint32_t                height;
    int                     format;        // HAL_PIXEL_FORMAT_*
    uint32_t                usage;         // GRALLOC_USAGE_* consumer flags (in), HAL may OR more

    // HAL-controlled, set during configure_streams()
    uint32_t                max_buffers;
    void                   *priv;          // HAL private data

    android_dataspace_t     data_space;
    int32_t                 rotation;      // camera3_stream_rotation_t

    // API level >= 3.5
    const char             *physical_camera_id;

    // Padding / reserved  (keep total size stable across AOSP versions)
    uint32_t                reserved[51];
} camera3_stream_t;

// ---------------------------------------------------------------------------
// camera3_stream_configuration_t
// ---------------------------------------------------------------------------
typedef struct camera3_stream_configuration {
    uint32_t            num_streams;
    camera3_stream_t  **streams;
    uint32_t            operation_mode;   // camera3_stream_configuration_mode_t
    const camera_metadata_t *session_parameters; // API >= 3.5, may be NULL
} camera3_stream_configuration_t;

// ---------------------------------------------------------------------------
// camera3_buffer_status_t / camera3_stream_buffer_t
// ---------------------------------------------------------------------------
typedef enum camera3_buffer_status {
    CAMERA3_BUFFER_STATUS_OK    = 0,
    CAMERA3_BUFFER_STATUS_ERROR = 1,
} camera3_buffer_status_t;

typedef struct camera3_stream_buffer {
    camera3_stream_t   *stream;
    buffer_handle_t    *buffer;           // ANativeWindowBuffer inside
    int                 status;           // camera3_buffer_status_t
    int                 acquire_fence;    // -1 when none
    int                 release_fence;    // HAL fills this, -1 when none
} camera3_stream_buffer_t;

// ---------------------------------------------------------------------------
// camera3_capture_result_t
// ---------------------------------------------------------------------------
typedef struct camera3_capture_result {
    uint32_t                        frame_number;
    const camera_metadata_t        *result;
    uint32_t                        num_output_buffers;
    const camera3_stream_buffer_t  *output_buffers;
    const camera3_stream_buffer_t  *input_buffer;   // NULL for non-reprocess
    uint32_t                        partial_result;  // 0 → not a partial
    uint32_t                        num_physcam_metadata;
    const char                    **physcam_ids;
    const camera_metadata_t       **physcam_metadata;
} camera3_capture_result_t;

// ---------------------------------------------------------------------------
// camera3_callback_ops_t — what cameraservice registers with the HAL
// ---------------------------------------------------------------------------
struct camera3_callback_ops {
    void (*process_capture_result)(const struct camera3_callback_ops *,
                                   const camera3_capture_result_t *);
    void (*notify)(const struct camera3_callback_ops *,
                   const struct camera3_notify_msg *);
    // API >= 3.5 — optional, may be NULL
    camera3_buffer_request_status_t (*request_stream_buffers)(
        const struct camera3_callback_ops *,
        uint32_t num_buffer_reqs,
        const camera3_buffer_request *buffer_reqs,
        uint32_t *num_returned_buf_reqs,
        camera3_stream_buffer_ret *returned_buf_reqs);
    void (*return_stream_buffers)(const struct camera3_callback_ops *,
                                  uint32_t num_buffers,
                                  const camera3_stream_buffer_t *const *buffers);
};
