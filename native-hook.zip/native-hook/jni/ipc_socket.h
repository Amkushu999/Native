#pragma once
// ipc_socket.h — Unix Domain Socket receiver for Ashmem FD transfer.
//
// The app writes the Ashmem fd into an abstract-namespace UDS socket.
// This module listens on that socket in a background thread and calls
// frame_source_init() whenever a new fd arrives (allowing hot-swap of
// the video source while the camera is open).

#ifdef __cplusplus
extern "C" {
#endif

// Abstract socket name (must match the app side).
#define AMKUSH_SOCKET_NAME "\0amkush_frame_fd"

// Start the background listener thread.
// Returns 0 on success.
int  ipc_socket_start(void);

// Stop the listener thread (called from destructor).
void ipc_socket_stop(void);

#ifdef __cplusplus
}
#endif
