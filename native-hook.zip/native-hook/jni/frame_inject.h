#pragma once
// frame_inject.h — Per-surface frame injection using libyuv + lockYCbCr.
//
// Takes a FrameData (raw NV12 master frame) and a camera3_stream_buffer_t,
// determines the destination format, scales/converts via libyuv, and writes
// directly into the GraphicBuffer via lockYCbCr() (YUV) or lock() (JPEG).
//
// JPEG encoding (for BLOB/snapshot streams) uses libjpeg-turbo.
//
// All GraphicBuffer access uses the Android libui.so dynamic resolution path
// (dlopen/dlsym at init time) so we don't need to link against libui at
// build time and avoid linker namespace conflicts.

#include "include/camera3_compat.h"
#include "frame_source.h"
#include "stream_map.h"

#ifdef __cplusplus
extern "C" {
#endif

// Initialize: resolve GraphicBuffer symbols via dlopen("libui.so").
// Must be called after the process has loaded libui.so (i.e. after
// the Zygisk constructor runs and cameraservice is live).
int  frame_inject_init(void);
void frame_inject_destroy(void);

// Inject a synthetic frame into one output buffer slot.
// Returns true if injection succeeded, false if skipped/failed.
bool frame_inject_one(const camera3_stream_buffer_t *buf,
                      StreamRole                     role,
                      const FrameData               *src);

#ifdef __cplusplus
}
#endif
