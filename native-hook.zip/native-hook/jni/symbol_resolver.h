#pragma once
// symbol_resolver.h — Runtime multi-version mangled symbol resolution.
//
// Problem: the C++ mangled name for Camera3Device::processCaptureResult
// changes across Android OS versions because Google refactored code from
// Camera3Device.cpp into Camera3OutputUtils.cpp in Android 13+. A single
// hardcoded mangled string only works on one API level.
//
// Solution: try a prioritized list of known mangled names via
// shadowhook_dlsym(), then fall back to __cxa_demangle-based scanning of
// the .dynsym table to match a partial demangled substring.
//
// A second hook point (configure_streams) follows the same strategy.

#ifdef __cplusplus
extern "C" {
#endif

// Opaque result returned by resolve_*().  ptr == NULL if not found.
typedef struct {
    void       *ptr;     // absolute virtual address in the process
    const char *symbol;  // matched mangled symbol string (static storage)
    const char *source;  // "known_list" or "demangle_scan"
} ResolvedSymbol;

// Resolve Camera3Device::processCaptureResult (or Camera3OutputUtils variant).
// Searches libcameraservice.so.
ResolvedSymbol resolve_process_capture_result(void);

// Resolve Camera3Device::configureStreams (the internal AOSP wrapper that
// calls camera3_device_ops::configure_streams).
ResolvedSymbol resolve_configure_streams(void);

#ifdef __cplusplus
}
#endif
