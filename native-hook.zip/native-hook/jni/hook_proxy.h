#pragma once
// hook_proxy.h — Camera hook installation and callback implementations.
//
// Two hooks are installed:
//
//   1. processCaptureResult (Camera3Device or Camera3OutputUtils)
//      — intercepts every outgoing camera frame
//      — injects synthetic frames from the shared-memory ring buffer
//      — handles multi-surface (preview / video / snapshot) routing
//
//   2. configureStreams (Camera3Device)
//      — intercepts stream setup at session start
//      — strips GRALLOC_USAGE_PROTECTED
//      — builds the stream identity map (stream_map)
//
// Both hooks use ShadowHook inline mode with crash_guard for safety.

#ifdef __cplusplus
extern "C" {
#endif

// Install both hooks. Returns 0 on success, -1 on failure.
// Must be called from inside the cameraserver process (Zygisk postSpecialize).
int  hook_proxy_install(void);

// Remove both hooks (called from destructor / unload).
void hook_proxy_uninstall(void);

// Returns true if at least the processCaptureResult hook is active.
bool hook_proxy_is_active(void);

// Runtime control: enable / disable frame injection without uninstalling.
void hook_proxy_set_enabled(bool enabled);

#ifdef __cplusplus
}
#endif
