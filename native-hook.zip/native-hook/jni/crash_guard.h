#pragma once
// crash_guard.h — sigaction / sigsetjmp crash recovery for the camera hook.
// Registers a SIGSEGV / SIGBUS handler that uses siglongjmp to abort a
// failing frame injection and fall back to the real camera data, preventing
// a cameraserver process death and the resulting phone reboot.

#include <setjmp.h>

#ifdef __cplusplus
extern "C" {
#endif

// Call once from the Zygisk constructor (before any hooks are active).
// Returns 0 on success.
int crash_guard_init(void);

// Call once from the Zygisk destructor (cleanup).
void crash_guard_cleanup(void);

// Per-frame guard: must be called at the top of the hooked callback.
// Returns 0 on normal entry, non-zero if we jumped here after a crash.
// Usage:
//   if (crash_guard_enter() != 0) { /* crashed — skip injection */ return; }
//   ... injection code ...
//   crash_guard_exit();
int  crash_guard_enter(void);
void crash_guard_exit(void);

#ifdef __cplusplus
}
#endif
